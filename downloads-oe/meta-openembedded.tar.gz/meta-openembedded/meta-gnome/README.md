Dependencies
------------
This layer depends on:

URI: git://git.openembedded.org/openembedded-core
branch: scarthgap

URI: git://git.openembedded.org/meta-openembedded
branch: scarthgap

Send pull requests to openembedded-devel@lists.openembedded.org with '[meta-gnome][scarthgap]' in the subject'

When sending single patches, please using something like:
git send-email -M -1 --to openembedded-devel@lists.openembedded.org --subject-prefix='meta-gnome][scarthgap][PATCH'

Layer maintainer: Armin Kuster <akuster808@gmail.com>
