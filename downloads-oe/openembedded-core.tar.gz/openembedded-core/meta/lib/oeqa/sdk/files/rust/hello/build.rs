/* This is the simplest build script just to invoke host compiler
   in the build process. */
fn main() {}
