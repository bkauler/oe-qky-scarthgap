int
      main()
      {
          printf("Hello, world!\n");
      }
