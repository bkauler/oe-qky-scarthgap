#include <limits>

int main() {}